# TEAMFIT AI Features - Quick Reference Guide

## 📚 Your Complete Documentation Package

### **Main Documents**

| Document | Purpose | When to Use |
|----------|---------|-------------|
| **[COMPREHENSIVE_BRAINSTORMING_SUMMARY.md](./COMPREHENSIVE_BRAINSTORMING_SUMMARY.md)** | Read this FIRST! Complete overview, decisions, roadmap | Understanding the full solution |
| **[CLAUDE_CODE_PROMPT_AI_FEATURES_DATABASE.md](./CLAUDE_CODE_PROMPT_AI_FEATURES_DATABASE.md)** | Copy & paste into Claude Code | Implementing database changes NOW |
| **[TEAMFIT_AI_FEATURES_IMPLEMENTATION_PLAN.md](./TEAMFIT_AI_FEATURES_IMPLEMENTATION_PLAN.md)** | Deep technical reference | Building backend/frontend features |
| **[sector_based_public_activities.sql](./sector_based_public_activities.sql)** | 45 sector-specific activities | Adding public activities to database |

---

## ✅ Implementation Checklist

### **Phase 1: Database Setup** (Week 1)

- [ ] Read COMPREHENSIVE_BRAINSTORMING_SUMMARY.md completely
- [ ] Understand all 5 new tables and their purpose
- [ ] Review pricing model and approve
- [ ] Open Claude Code with Supabase MCP enabled
- [ ] Copy CLAUDE_CODE_PROMPT_AI_FEATURES_DATABASE.md
- [ ] Paste into Claude Code and execute
- [ ] Wait for completion (5-10 minutes)
- [ ] Verify all tables created:
  ```sql
  SELECT table_name FROM information_schema.tables 
  WHERE table_schema = 'public' 
  AND table_name IN (
    'team_profiles', 'uploaded_materials', 'customization_jobs',
    'customized_activities', 'usage_quotas'
  );
  ```
- [ ] Verify RLS policies (should see 20 new policies)
- [ ] Create Supabase Storage bucket:
  - Name: `team-materials`
  - Public: No
  - Max file size: 10MB
  - Allowed types: .pptx, .docx, .pdf, .xlsx
- [ ] Optionally: Import 45 sector activities using sector_based_public_activities.sql
- [ ] Generate updated TypeScript types
- [ ] Commit changes to git

---

### **Phase 2: Backend Setup** (Week 1-2)

- [ ] Get OpenAI API key (https://platform.openai.com)
  - Or Anthropic API key (https://console.anthropic.com)
- [ ] Add to environment variables:
  ```bash
  OPENAI_API_KEY=sk-...
  # or
  ANTHROPIC_API_KEY=sk-ant-...
  ```
- [ ] Install Python libraries:
  ```bash
  pip install openai anthropic pypdf pdfplumber python-docx python-pptx openpyxl
  ```
- [ ] Install Redis for job queue:
  ```bash
  # macOS
  brew install redis
  brew services start redis
  
  # Linux
  sudo apt-get install redis-server
  sudo systemctl start redis
  ```
- [ ] Install Celery:
  ```bash
  pip install celery
  ```
- [ ] Test Redis connection:
  ```python
  import redis
  r = redis.Redis(host='localhost', port=6379, db=0)
  r.ping()  # Should return True
  ```

---

### **Phase 3: API Endpoints** (Week 2)

Create these FastAPI endpoints:

- [ ] `POST /api/team-profiles` - Create/update team profile
- [ ] `GET /api/team-profiles/{team_id}` - Get team profile
- [ ] `POST /api/materials/upload` - Upload activity materials (paid only)
- [ ] `GET /api/materials/{team_id}` - List uploaded materials
- [ ] `DELETE /api/materials/{id}` - Delete material
- [ ] `POST /api/activities/customize` - Customize public activity
- [ ] `POST /api/activities/generate-custom` - Generate custom activities (async)
- [ ] `GET /api/jobs/{job_id}` - Check generation job status
- [ ] `GET /api/quotas/{org_id}` - Check remaining quotas
- [ ] `PATCH /api/activities/{id}` - Edit customized activity
- [ ] `POST /api/activities/{id}/schedule` - Schedule activity as event

---

### **Phase 4: Frontend Components** (Week 3-4)

Create these React components:

- [ ] `TeamProfileForm` - Collect team information
- [ ] `FileUploadZone` - Drag & drop file upload (paid users)
- [ ] `ActivityCustomizer` - Show customization form + results
- [ ] `JobStatusTracker` - Poll for custom generation status
- [ ] `CustomizedActivityCard` - Display AI-generated activity
- [ ] `ActivityManager` - View/edit/schedule customized activities  
- [ ] `QuotaIndicator` - Show remaining monthly quotas
- [ ] `TrustScoreWarning` - Notify if verification required

---

### **Phase 5: Testing** (Week 4)

- [ ] Unit tests for file extraction
- [ ] Unit tests for trust score calculation
- [ ] Integration test: Free user customization flow
- [ ] Integration test: Paid user custom generation flow
- [ ] Integration test: Quota enforcement
- [ ] Integration test: Abuse detection
- [ ] Load test: 10 concurrent customizations
- [ ] Load test: 100 file uploads
- [ ] E2E test: Complete user journey (signup → customize → schedule)

---

## 🎯 Key Numbers to Remember

| Metric | Value |
|--------|-------|
| **AI Cost Budget** | $3.50/user/month max |
| **Actual AI Cost (Free)** | $0.006/user/month |
| **Actual AI Cost (Paid)** | $0.56/user/month |
| **Free Tier Quota** | 5 customizations/org/month |
| **Paid Tier Quota (Public)** | Unlimited |
| **Paid Tier Quota (Custom)** | 10 generations/org/month |
| **Max File Size** | 10MB per file |
| **Max Team Storage** | 50MB |
| **Suggestion Expiration** | 30 days |
| **New Tables Added** | 5 |
| **New RLS Policies** | 20 |
| **New Functions** | 4 |

---

## 💰 Pricing Quick Reference

| Plan | Price/Month | Teams | Public Customizations | Custom Generations | Storage |
|------|-------------|-------|----------------------|-------------------|---------|
| **Free** | $0 | Any | 5/month | 0 | 0 |
| **Pro (1 Team)** | $29 | 1 | Unlimited | 10/month | 50MB |
| **Pro (2-4 Teams)** | $79 | 2-4 | Unlimited | 10/month per team | 200MB |
| **Enterprise (5+)** | $199 | 5+ | Unlimited | 10/month per team | 500MB |

**Profit Margins:** ~80% across all paid tiers ✅

---

## 🔄 User Flows

### **Free User - Public Customization**
```
1. Create team profile (text only)
2. Browse 15 public activities
3. Click "Customize for My Team"
4. Wait 10-30 seconds (real-time)
5. Review AI-customized activity
6. Either:
   - Schedule immediately
   - Save for later
   - Regenerate (uses another quota)
```

### **Paid User - Custom Generation**
```
1. Create/update team profile
2. Upload activity materials (PPT, docs, PDFs)
3. Click "Generate Custom Activities"
4. Submit job (get job_id)
5. Poll status every 5 seconds
6. Receive 3 AI-generated suggestions
7. Review all 3 activities
8. Pick one to schedule
9. Save others for future use
```

---

## 🛡️ Abuse Prevention Quick Guide

### **Trust Score Thresholds**

| Score | Trust Level | Free Quota | Action Required |
|-------|-------------|------------|-----------------|
| 0.80 - 1.00 | High | 5/month | None |
| 0.60 - 0.79 | Medium | 3/month | Email verification |
| 0.00 - 0.59 | Low | 1/month | Email + manual review |

### **Red Flags (Trust Score Deductions)**
- New org (< 1 day): -0.30
- New org (< 7 days): -0.20
- No teams: -0.25
- Only 1 member: -0.25
- Disposable email: -0.40

### **Green Flags (Trust Score Additions)**
- Payment method added: +0.15
- Org age > 30 days: +0.10
- Active team usage: +0.10

---

## 📊 Database Table Relationships

```
organizations (1) ←→ (1) subscriptions
    ↓
teams (M) ←→ (1) team_profiles
    ↓
customized_activities (M)
    ↓
scheduled_events (M)
    ↓
feedback (M)

organizations (1) ←→ (1) usage_quotas
teams (M) ←→ (M) uploaded_materials
teams (M) ←→ (M) customization_jobs
jobs (1) ←→ (M) customized_activities
```

---

## 🚨 Common Issues & Quick Fixes

### **Issue: Quota Not Resetting**
```sql
-- Manually trigger quota reset
SELECT reset_monthly_quotas();
```

### **Issue: Trust Score Too Low**
```sql
-- Check current trust score
SELECT calculate_trust_score('org-id-here');

-- Manually adjust if needed
UPDATE usage_quotas 
SET trust_score = 0.80, requires_verification = false
WHERE organization_id = 'org-id-here';
```

### **Issue: Job Stuck in "Processing"**
```sql
-- Find stuck jobs (> 10 minutes)
SELECT * FROM customization_jobs 
WHERE status = 'processing' 
AND created_at < NOW() - INTERVAL '10 minutes';

-- Mark as failed
UPDATE customization_jobs 
SET status = 'failed', error_message = 'Timeout'
WHERE id = 'job-id-here';
```

### **Issue: File Upload Fails**
1. Check file size (< 10MB)
2. Check file type (.pptx, .docx, .pdf, .xlsx only)
3. Check team storage limit (< 50MB total)
4. Check Supabase Storage bucket permissions

---

## 🎓 AI Prompt Examples

### **Public Activity Customization**
```
Input:
- Activity: "Tech Trivia Tournament (30 min)"
- Team: "React development team at startup"
- Responsibilities: "Building e-commerce platform"
- Past: "Done code reviews, pair programming"

Output:
- Title: "React & E-commerce Tech Challenge (30 min)"
- Description: "Test your React and e-commerce knowledge..."
- Instructions: "Questions focus on hooks, state management, payment APIs..."
```

### **Custom Activity Generation**
```
Input:
- Team: "Customer support team, 12 members"
- Materials: "Past training slides on empathy, conflict resolution"
- Industry: "SaaS company"

Output (3 activities):
1. "Empathy Role-Play Challenge" (30 min)
2. "Support Ticket Speed Run" (15 min)
3. "Customer Success Story Sharing" (45 min)
```

---

## 📞 Support & Next Steps

### **If You Need Help**
1. Review COMPREHENSIVE_BRAINSTORMING_SUMMARY.md
2. Check TEAMFIT_AI_FEATURES_IMPLEMENTATION_PLAN.md for technical details
3. Search this quick reference guide
4. Ask me specific questions

### **Ready to Start?**
1. ✅ Read comprehensive brainstorming summary
2. ✅ Run database prompt in Claude Code
3. ✅ Verify tables created successfully
4. ✅ Tell me you're ready for Phase 2 (backend implementation)

---

## 🎯 Success Criteria

By the end of implementation, you should have:

- ✅ 5 new database tables with RLS
- ✅ File upload working for paid users
- ✅ AI customization generating relevant activities
- ✅ Async job queue processing custom generations
- ✅ Quota enforcement preventing abuse
- ✅ Trust scoring identifying suspicious orgs
- ✅ Frontend showing AI results beautifully
- ✅ Users upgrading from free to paid
- ✅ AI costs under $3.50/user/month
- ✅ 80% profit margins on paid tiers

---

**Last Updated:** November 23, 2025  
**Version:** 1.0  
**Status:** Ready for Implementation ✅

**Next Action:** Run CLAUDE_CODE_PROMPT_AI_FEATURES_DATABASE.md in Claude Code!
