-- TEAMFIT Public Activities - Sector-Specific Activities
-- 45 total activities: 15 base activities × 3 duration variants (15min, 30min, 45min)
-- Categories: tech_it, marketing_creative, finance_accounting, business_services, customer_service

-- ============================================
-- SECTOR 1: TECHNOLOGY & IT (3 activities)
-- ============================================

-- Activity 1: Code Challenge Sprint
INSERT INTO "public"."public_activities" ("id", "title", "description", "category", "duration_minutes", "complexity", "required_tools", "instructions", "is_active", "created_at", "updated_at") VALUES 
('a1b2c3d4-1111-4444-8888-111111111115', 'Code Challenge Sprint (15 min)', 'Quick coding puzzle race for developers', 'tech_it', 15, 'easy', '["Video conferencing","Code editor or coding platform"]', 'Share a simple algorithm puzzle (e.g., FizzBuzz variant). Teams code solutions and share screens. First correct solution wins.', true, NOW(), NOW()),
('a1b2c3d4-1111-4444-8888-111111111130', 'Code Challenge Sprint (30 min)', 'Coding challenge with debugging and testing', 'tech_it', 30, 'medium', '["Video conferencing","Code editor or coding platform"]', 'Present a buggy code snippet with 3-5 errors. Teams debug, fix, and test solutions. Discuss approaches at the end.', true, NOW(), NOW()),
('a1b2c3d4-1111-4444-8888-111111111145', 'Code Challenge Sprint (45 min)', 'Build a mini-feature coding competition', 'tech_it', 45, 'hard', '["Video conferencing","Code editor or coding platform","Version control"]', 'Teams build a small feature (e.g., REST API endpoint, calculator). Present working demos. Vote on best implementation.', true, NOW(), NOW());

-- Activity 2: Tech Trivia Tournament
INSERT INTO "public"."public_activities" ("id", "title", "description", "category", "duration_minutes", "complexity", "required_tools", "instructions", "is_active", "created_at", "updated_at") VALUES 
('a1b2c3d4-2222-4444-8888-222222222215', 'Tech Trivia Tournament (15 min)', 'Rapid-fire tech knowledge quiz', 'tech_it', 15, 'easy', '["Video conferencing","Trivia questions"]', 'Prepare 15-20 tech questions (languages, history, trends). Use Zoom polls or chat for answers. Tally scores and announce winner.', true, NOW(), NOW()),
('a1b2c3d4-2222-4444-8888-222222222230', 'Tech Trivia Tournament (30 min)', 'Multi-round tech trivia with team discussion', 'tech_it', 30, 'medium', '["Video conferencing","Trivia questions","Breakout rooms"]', 'Create 30-40 questions in 3 categories. Teams discuss in breakout rooms before answering. Keep score and declare champion.', true, NOW(), NOW()),
('a1b2c3d4-2222-4444-8888-222222222245', 'Tech Trivia Tournament (45 min)', 'Comprehensive tech quiz with bonus rounds', 'tech_it', 45, 'medium', '["Video conferencing","Trivia questions","Breakout rooms","Visual aids"]', 'Prepare 50+ questions across 4-5 rounds including visual/audio rounds. Include lightning rounds and final jeopardy. Award prizes.', true, NOW(), NOW());

-- Activity 3: Virtual Escape Room - Tech Mystery
INSERT INTO "public"."public_activities" ("id", "title", "description", "category", "duration_minutes", "complexity", "required_tools", "instructions", "is_active", "created_at", "updated_at") VALUES 
('a1b2c3d4-3333-4444-8888-333333333315', 'Virtual Escape Room - Tech Mystery (15 min)', 'Quick puzzle-solving challenge', 'tech_it', 15, 'medium', '["Video conferencing","Digital puzzles or riddles"]', 'Create 2-3 interconnected tech puzzles. Teams solve collaboratively using shared screen. First team to finish wins.', true, NOW(), NOW()),
('a1b2c3d4-3333-4444-8888-333333333330', 'Virtual Escape Room - Tech Mystery (30 min)', 'Standard tech-themed escape room', 'tech_it', 30, 'hard', '["Video conferencing","Escape room platform or puzzles","Shared documents"]', 'Design 5-7 puzzles (code breaking, logic gates, tech riddles). Teams work together. Track time and hints used.', true, NOW(), NOW()),
('a1b2c3d4-3333-4444-8888-333333333345', 'Virtual Escape Room - Tech Mystery (45 min)', 'Complex multi-room tech escape challenge', 'tech_it', 45, 'hard', '["Video conferencing","Escape room platform","Breakout rooms","Shared documents"]', 'Create immersive hacking scenario with multiple rooms and advanced puzzles. Include plot twists and red herrings. Debrief at end.', true, NOW(), NOW());

-- ============================================
-- SECTOR 2: MARKETING & CREATIVE (3 activities)
-- ============================================

-- Activity 4: Creative Campaign Clash
INSERT INTO "public"."public_activities" ("id", "title", "description", "category", "duration_minutes", "complexity", "required_tools", "instructions", "is_active", "created_at", "updated_at") VALUES 
('b2c3d4e5-1111-4444-8888-444444444415', 'Creative Campaign Clash (15 min)', 'Quick tagline and pitch competition', 'marketing_creative', 15, 'easy', '["Video conferencing"]', 'Present a fictional product. Teams create a catchy tagline and 30-second elevator pitch. Present and vote on winner.', true, NOW(), NOW()),
('b2c3d4e5-1111-4444-8888-444444444430', 'Creative Campaign Clash (30 min)', 'Campaign concept development challenge', 'marketing_creative', 30, 'medium', '["Video conferencing","Digital whiteboard or slides"]', 'Share product brief. Teams develop tagline, key message, and visual concept. Create simple mockup and 2-minute pitch.', true, NOW(), NOW()),
('b2c3d4e5-1111-4444-8888-444444444445', 'Creative Campaign Clash (45 min)', 'Full marketing campaign competition', 'marketing_creative', 45, 'hard', '["Video conferencing","Design tools","Digital whiteboard"]', 'Provide detailed product brief. Teams create complete campaign: tagline, visuals, social posts, and strategy. Present 5-minute pitch.', true, NOW(), NOW());

-- Activity 5: Story Chain Challenge
INSERT INTO "public"."public_activities" ("id", "title", "description", "category", "duration_minutes", "complexity", "required_tools", "instructions", "is_active", "created_at", "updated_at") VALUES 
('b2c3d4e5-2222-4444-8888-555555555515', 'Story Chain Challenge (15 min)', 'Quick collaborative storytelling', 'marketing_creative', 15, 'easy', '["Video conferencing","Shared document"]', 'Start with opening sentence. Each person adds 1-2 sentences in turn. Read final story aloud and vote on best contributions.', true, NOW(), NOW()),
('b2c3d4e5-2222-4444-8888-555555555530', 'Story Chain Challenge (30 min)', 'Brand story building workshop', 'marketing_creative', 30, 'medium', '["Video conferencing","Shared document","Screen sharing"]', 'Provide brand context. Build narrative with 15-20 contributions including plot twists. Discuss story arc and character development.', true, NOW(), NOW()),
('b2c3d4e5-2222-4444-8888-555555555545', 'Story Chain Challenge (45 min)', 'Epic content creation adventure', 'marketing_creative', 45, 'medium', '["Video conferencing","Shared document","Digital whiteboard"]', 'Create multi-chapter story with team input. Include visual elements and character development. Polish final version collaboratively.', true, NOW(), NOW());

-- Activity 6: Design Sprint - Pixel Art Challenge
INSERT INTO "public"."public_activities" ("id", "title", "description", "category", "duration_minutes", "complexity", "required_tools", "instructions", "is_active", "created_at", "updated_at") VALUES 
('b2c3d4e5-3333-4444-8888-666666666615', 'Design Sprint - Pixel Art (15 min)', 'Quick icon design competition', 'marketing_creative', 15, 'easy', '["Video conferencing","Spreadsheet or pixel art tool"]', 'Assign theme (e.g., tech startup). Create simple 16x16 pixel icon. Share designs and vote on most creative.', true, NOW(), NOW()),
('b2c3d4e5-3333-4444-8888-666666666630', 'Design Sprint - Pixel Art (30 min)', 'Logo design pixel challenge', 'marketing_creative', 30, 'medium', '["Video conferencing","Spreadsheet or pixel art tool","Screen sharing"]', 'Design company logo in 32x32 pixels. Include color palette and concept explanation. Present rationale for design choices.', true, NOW(), NOW()),
('b2c3d4e5-3333-4444-8888-666666666645', 'Design Sprint - Pixel Art (45 min)', 'Complex pixel art scene creation', 'marketing_creative', 45, 'hard', '["Video conferencing","Pixel art tool","Digital whiteboard"]', 'Create detailed 64x64 scene or illustration. Include background story and design iterations. Vote and discuss artistic choices.', true, NOW(), NOW());

-- ============================================
-- SECTOR 3: FINANCE & ACCOUNTING (3 activities)
-- ============================================

-- Activity 7: Financial Feud Game
INSERT INTO "public"."public_activities" ("id", "title", "description", "category", "duration_minutes", "complexity", "required_tools", "instructions", "is_active", "created_at", "updated_at") VALUES 
('c3d4e5f6-1111-4444-8888-777777777715', 'Financial Feud Game (15 min)', 'Quick finance quiz game show', 'finance_accounting', 15, 'easy', '["Video conferencing","Quiz questions"]', 'Prepare 3-4 finance-themed questions with top survey answers. Teams buzz in with guesses. Award points for correct answers.', true, NOW(), NOW()),
('c3d4e5f6-1111-4444-8888-777777777730', 'Financial Feud Game (30 min)', 'Multi-round finance game show', 'finance_accounting', 30, 'medium', '["Video conferencing","Quiz questions","Scoring system"]', 'Create 8-10 questions across categories (accounting, markets, regulations). Include team consultations and bonus rounds.', true, NOW(), NOW()),
('c3d4e5f6-1111-4444-8888-777777777745', 'Financial Feud Game (45 min)', 'Full finance championship game', 'finance_accounting', 45, 'medium', '["Video conferencing","Quiz questions","Breakout rooms","Visual aids"]', 'Host complete game show with 4-5 rounds, fast money round, and audience participation. Include financial trivia and industry insights.', true, NOW(), NOW());

-- Activity 8: Budget Master Challenge
INSERT INTO "public"."public_activities" ("id", "title", "description", "category", "duration_minutes", "complexity", "required_tools", "instructions", "is_active", "created_at", "updated_at") VALUES 
('c3d4e5f6-2222-4444-8888-888888888815', 'Budget Master Challenge (15 min)', 'Quick budget allocation exercise', 'finance_accounting', 15, 'easy', '["Video conferencing","Spreadsheet"]', 'Present simple scenario with budget to allocate across 3-4 categories. Teams decide splits and justify choices in 1 minute.', true, NOW(), NOW()),
('c3d4e5f6-2222-4444-8888-888888888830', 'Budget Master Challenge (30 min)', 'Strategic budget planning game', 'finance_accounting', 30, 'medium', '["Video conferencing","Spreadsheet","Screen sharing"]', 'Provide business case with 6-8 spending categories. Teams create detailed budget with justifications and present to "executives."', true, NOW(), NOW()),
('c3d4e5f6-2222-4444-8888-888888888845', 'Budget Master Challenge (45 min)', 'Complex financial scenario competition', 'finance_accounting', 45, 'hard', '["Video conferencing","Spreadsheet","Financial modeling tools"]', 'Present multi-year scenario with constraints and trade-offs. Teams build complete financial plan with ROI analysis and competitive pitch.', true, NOW(), NOW());

-- Activity 9: Market Prediction Game
INSERT INTO "public"."public_activities" ("id", "title", "description", "category", "duration_minutes", "complexity", "required_tools", "instructions", "is_active", "created_at", "updated_at") VALUES 
('c3d4e5f6-3333-4444-8888-999999999915', 'Market Prediction Game (15 min)', 'Quick market scenario predictions', 'finance_accounting', 15, 'easy', '["Video conferencing","Quiz materials"]', 'Present 3-4 market scenarios. Teams predict outcomes (rise/fall/stable). Reveal answers and discuss reasoning.', true, NOW(), NOW()),
('c3d4e5f6-3333-4444-8888-999999999930', 'Market Prediction Game (30 min)', 'Data analysis and forecasting game', 'finance_accounting', 30, 'medium', '["Video conferencing","Spreadsheet with data","Screen sharing"]', 'Share 5-7 scenarios with trend data. Teams analyze, discuss strategy, and predict outcomes. Compare predictions and discuss insights.', true, NOW(), NOW()),
('c3d4e5f6-3333-4444-8888-999999999945', 'Market Prediction Game (45 min)', 'Portfolio strategy simulation', 'finance_accounting', 45, 'hard', '["Video conferencing","Financial simulation tool","Breakout rooms"]', 'Run multi-round market simulation. Teams build portfolios, react to changing conditions, and track performance. Debrief on strategies.', true, NOW(), NOW());

-- ============================================
-- SECTOR 4: PROFESSIONAL & BUSINESS SERVICES (3 activities)
-- ============================================

-- Activity 10: Virtual Case Study Showdown
INSERT INTO "public"."public_activities" ("id", "title", "description", "category", "duration_minutes", "complexity", "required_tools", "instructions", "is_active", "created_at", "updated_at") VALUES 
('d4e5f6g7-1111-4444-8888-101010101015', 'Virtual Case Study Showdown (15 min)', 'Quick problem-solving challenge', 'business_services', 15, 'easy', '["Video conferencing"]', 'Present simple business problem. Teams brainstorm solutions for 10 minutes and pitch 2-minute recommendation.', true, NOW(), NOW()),
('d4e5f6g7-1111-4444-8888-101010101030', 'Virtual Case Study Showdown (30 min)', 'Detailed case analysis competition', 'business_services', 30, 'medium', '["Video conferencing","Digital whiteboard","Screen sharing"]', 'Share business case with data. Teams analyze using frameworks, develop strategy, and present 5-minute solution with Q&A.', true, NOW(), NOW()),
('d4e5f6g7-1111-4444-8888-101010101045', 'Virtual Case Study Showdown (45 min)', 'Complex consulting-style case study', 'business_services', 45, 'hard', '["Video conferencing","Breakout rooms","Presentation tools"]', 'Provide comprehensive case with research phase. Teams create full strategic recommendation with 10-minute pitch and executive Q&A.', true, NOW(), NOW());

-- Activity 11: Project Management Race
INSERT INTO "public"."public_activities" ("id", "title", "description", "category", "duration_minutes", "complexity", "required_tools", "instructions", "is_active", "created_at", "updated_at") VALUES 
('d4e5f6g7-2222-4444-8888-111111111115', 'Project Management Race (15 min)', 'Quick project sequencing game', 'business_services', 15, 'easy', '["Video conferencing","Project task list"]', 'Give fictional project with 5-6 tasks. Teams sequence tasks, assign owners, and create basic timeline. Present and compare approaches.', true, NOW(), NOW()),
('d4e5f6g7-2222-4444-8888-111111111130', 'Project Management Race (30 min)', 'Project planning competition', 'business_services', 30, 'medium', '["Video conferencing","Project management tool or spreadsheet"]', 'Present medium-complexity project. Teams create plan with dependencies, milestones, and risk assessment. Pitch plan to stakeholders.', true, NOW(), NOW()),
('d4e5f6g7-2222-4444-8888-111111111145', 'Project Management Race (45 min)', 'Complex project strategy simulation', 'business_services', 45, 'hard', '["Video conferencing","PM software","Breakout rooms"]', 'Provide multi-stream project with constraints. Teams build comprehensive plan including resources, risks, communications, and contingencies.', true, NOW(), NOW());

-- Activity 12: Business Improv Challenge
INSERT INTO "public"."public_activities" ("id", "title", "description", "category", "duration_minutes", "complexity", "required_tools", "instructions", "is_active", "created_at", "updated_at") VALUES 
('d4e5f6g7-3333-4444-8888-121212121215', 'Business Improv Challenge (15 min)', 'Quick professional improv games', 'business_services', 15, 'easy', '["Video conferencing"]', 'Play 2-3 quick improv games like "Pitch This" (sell random object) or "Meeting Mayhem" (role-play scenarios). Keep it fun and light.', true, NOW(), NOW()),
('d4e5f6g7-3333-4444-8888-121212121230', 'Business Improv Challenge (30 min)', 'Communication skills improv workshop', 'business_services', 30, 'medium', '["Video conferencing","Scenario cards"]', 'Run 4-5 structured improv games focusing on presentation and communication. Debrief after each on key learnings.', true, NOW(), NOW()),
('d4e5f6g7-3333-4444-8888-121212121245', 'Business Improv Challenge (45 min)', 'Advanced professional development improv', 'business_services', 45, 'medium', '["Video conferencing","Scenario library","Breakout rooms"]', 'Full improv session with warm-ups, multiple games, and reflection on communication patterns. Include role-play scenarios and skill practice.', true, NOW(), NOW());

-- ============================================
-- SECTOR 5: CUSTOMER SERVICE & SUPPORT (3 activities)
-- ============================================

-- Activity 13: Customer Scenario Showdown
INSERT INTO "public"."public_activities" ("id", "title", "description", "category", "duration_minutes", "complexity", "required_tools", "instructions", "is_active", "created_at", "updated_at") VALUES 
('e5f6g7h8-1111-4444-8888-131313131315', 'Customer Scenario Showdown (15 min)', 'Quick customer service role-play', 'customer_service', 15, 'easy', '["Video conferencing","Scenario cards"]', 'Present 2-3 customer scenarios. Pairs role-play (customer and agent). Discuss best practices and resolution approaches after each.', true, NOW(), NOW()),
('e5f6g7h8-1111-4444-8888-131313131330', 'Customer Scenario Showdown (30 min)', 'Escalation handling workshop', 'customer_service', 30, 'medium', '["Video conferencing","Scenario library","Screen sharing"]', 'Use 4-5 escalating difficulty scenarios. Teams problem-solve together, then role-play resolutions. Award points for best handling.', true, NOW(), NOW()),
('e5f6g7h8-1111-4444-8888-131313131345', 'Customer Scenario Showdown (45 min)', 'Advanced service challenge tournament', 'customer_service', 45, 'hard', '["Video conferencing","Breakout rooms","Feedback forms"]', 'Multi-round competition with complex scenarios. Include peer feedback, best practices discussion, and awards for excellence.', true, NOW(), NOW());

-- Activity 14: Empathy Mapping Workshop
INSERT INTO "public"."public_activities" ("id", "title", "description", "category", "duration_minutes", "complexity", "required_tools", "instructions", "is_active", "created_at", "updated_at") VALUES 
('e5f6g7h8-2222-4444-8888-141414141415', 'Empathy Mapping Workshop (15 min)', 'Quick customer empathy exercise', 'customer_service', 15, 'easy', '["Video conferencing","Digital whiteboard"]', 'Choose one customer persona. Teams quickly map what they think, feel, say, and do. Share insights on supporting them better.', true, NOW(), NOW()),
('e5f6g7h8-2222-4444-8888-141414141430', 'Empathy Mapping Workshop (30 min)', 'Detailed persona empathy session', 'customer_service', 30, 'medium', '["Video conferencing","Digital whiteboard","Templates"]', 'Create comprehensive empathy map including pain points, gains, and support touchpoints. Discuss insights and action items.', true, NOW(), NOW()),
('e5f6g7h8-2222-4444-8888-141414141445', 'Empathy Mapping Workshop (45 min)', 'Multi-persona strategy development', 'customer_service', 45, 'medium', '["Video conferencing","Collaboration tools","Breakout rooms"]', 'Map multiple customer personas. Compare differences, develop tailored support strategies, and create action plan for implementation.', true, NOW(), NOW());

-- Activity 15: Service Excellence Trivia
INSERT INTO "public"."public_activities" ("id", "title", "description", "category", "duration_minutes", "complexity", "required_tools", "instructions", "is_active", "created_at", "updated_at") VALUES 
('e5f6g7h8-3333-4444-8888-151515151515', 'Service Excellence Trivia (15 min)', 'Quick customer service quiz', 'customer_service', 15, 'easy', '["Video conferencing","Trivia questions"]', 'Prepare 15-20 questions about service best practices and famous customer wins. Use polls or chat. Tally scores and declare winner.', true, NOW(), NOW()),
('e5f6g7h8-3333-4444-8888-151515151530', 'Service Excellence Trivia (30 min)', 'Multi-category service trivia game', 'customer_service', 30, 'medium', '["Video conferencing","Trivia questions","Breakout rooms"]', 'Create 30-40 questions across categories (difficult customers, best practices, famous stories). Teams discuss before answering.', true, NOW(), NOW()),
('e5f6g7h8-3333-4444-8888-151515151545', 'Service Excellence Trivia (45 min)', 'Championship service knowledge quiz', 'customer_service', 45, 'medium', '["Video conferencing","Trivia platform","Breakout rooms","Visual aids"]', 'Run 50+ questions with themed rounds including scenarios and best practice challenges. Include lightning rounds and prizes.', true, NOW(), NOW());
